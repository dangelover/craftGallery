const inputs = document.querySelectorAll(".input");
const dni = document.querySelector("#dni");


// dni.addEventListener("click", () => {
// dni.classList.add("focus");
// })

function addcl() {
    let parent = this.parentNode.parentNode;
    parent.classList.add("focus");
    let parent2 = this.parentNode.parentNode.parentNode.parentNode;
    parent2.classList.add("focus");
    let parent3 = this.parentNode.parentNode.parentNode.lastElementChild;
    parent3.classList.add("focus");
    let parent4 = this.parentNode.parentNode.parentNode.parentNode.parentNode.firstElementChild;
    parent4.classList.add("focus");
}

function remcl() {
    let parent = this.parentNode.parentNode;
    if (this.value == "") {
        parent.classList.remove("focus");
    }
    let parent2 = this.parentNode.parentNode.parentNode.parentNode;
    if (this.value == "") {
        parent2.classList.remove("focus");
    }
    let parent3 = this.parentNode.parentNode.parentNode.lastElementChild;
    if (this.value == "") {
        parent3.classList.remove("focus");
    }
    let parent4 = this.parentNode.parentNode.parentNode.parentNode.parentNode.firstElementChild;
    if (this.value == "") {
        parent4.classList.remove("focus");
    }

}
inputs.forEach((input) => {
    // evento
    input.addEventListener("focus", addcl);
    input.addEventListener("blur", remcl);
});