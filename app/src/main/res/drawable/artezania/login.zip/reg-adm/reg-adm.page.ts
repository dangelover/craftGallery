import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-adm',
  templateUrl: './reg-adm.page.html',
  styleUrls: ['./reg-adm.page.scss'],
})
export class RegAdmPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
