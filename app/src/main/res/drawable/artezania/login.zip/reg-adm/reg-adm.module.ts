import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegAdmPageRoutingModule } from './reg-adm-routing.module';

import { RegAdmPage } from './reg-adm.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegAdmPageRoutingModule
  ],
  declarations: [RegAdmPage]
})
export class RegAdmPageModule {}
