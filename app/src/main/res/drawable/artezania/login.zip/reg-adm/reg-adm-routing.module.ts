import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegAdmPage } from './reg-adm.page';

const routes: Routes = [
  {
    path: '',
    component: RegAdmPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegAdmPageRoutingModule {}
