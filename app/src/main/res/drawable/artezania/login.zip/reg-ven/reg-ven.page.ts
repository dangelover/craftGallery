import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-ven',
  templateUrl: './reg-ven.page.html',
  styleUrls: ['./reg-ven.page.scss'],
})
export class RegVenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
