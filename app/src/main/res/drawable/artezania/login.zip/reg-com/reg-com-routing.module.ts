import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegComPage } from './reg-com.page';

const routes: Routes = [
  {
    path: '',
    component: RegComPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegComPageRoutingModule {}
