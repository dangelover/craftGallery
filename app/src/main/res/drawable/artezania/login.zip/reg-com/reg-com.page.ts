import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-com',
  templateUrl: './reg-com.page.html',
  styleUrls: ['./reg-com.page.scss'],
})
export class RegComPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
