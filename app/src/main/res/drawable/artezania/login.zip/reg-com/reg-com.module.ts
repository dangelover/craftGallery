import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegComPageRoutingModule } from './reg-com-routing.module';

import { RegComPage } from './reg-com.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegComPageRoutingModule
  ],
  declarations: [RegComPage]
})
export class RegComPageModule {}
