import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegDisPage } from './reg-dis.page';

const routes: Routes = [
  {
    path: '',
    component: RegDisPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegDisPageRoutingModule {}
