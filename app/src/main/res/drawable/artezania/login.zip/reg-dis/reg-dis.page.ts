import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-dis',
  templateUrl: './reg-dis.page.html',
  styleUrls: ['./reg-dis.page.scss'],
})
export class RegDisPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
